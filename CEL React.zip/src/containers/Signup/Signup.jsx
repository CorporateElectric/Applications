import React, { Component } from 'react';
import { Link } from "react-router-dom";
import config from './../../config';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Formik } from 'formik';
import 'react-toastify/dist/ReactToastify.css';
import './Signup.css';

class Signup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            baseURI: config.baseURI,
            fullName: '',
            email: '',
            phoneNumber: '',
            password: ''
        };
        toast.configure();
    }

    handleInputChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    handleSubmit = (value) => {
        let data = {
            fullName: value.fullName,
            email: value.email,
            phone: value.phoneNumber,
            password: value.password
        };

        axios({
            url: `${this.state.baseURI}users/register`,
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json;charset=UTF-8'
            },
            data
        }).then(response => {
            if (response.data.status) {
                toast.success(`${response.data.message}!`);
                this.props.history.push('/login');
            } else {
                toast.error(`${response.data.message}!`);
            }
        });
    }

    render() {
        return (
            <React.Fragment>
                <section className="page_wrap signup">
                    <div className="container">
                        <div className="row">
                            <div className="col-12">
                                <div className="cp_login_box border rounded-lg p-4 bg-light mx-auto">
                                    <div className="title_box text-center">
                                        <h1 className="primary_title">Sign up</h1>
                                    </div>

                                    <Formik
                                        initialValues={{ fullName: '', email: '', phoneNumber: '', password: '' }}
                                        validate={values => {
                                            const errors = {};
                                            if (!values.fullName) {
                                                errors.fullName = 'Full name is required.';
                                            }

                                            if (!values.email) {
                                                errors.email = 'Email is required.';
                                            } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
                                                errors.email = 'Invalid email address.';
                                            }

                                            if (!values.phoneNumber) {
                                                errors.phoneNumber = 'Phone no. is required.';
                                            } else if (values.phoneNumber.length < 10) {
                                                errors.phoneNumber = 'Phone no. should be 10 digits.';
                                            } else {
                                                var pattern = new RegExp(/^[0-9\b]+$/);
                                                if (!pattern.test(values.phoneNumber)) {
                                                    errors.phoneNumber = 'Please enter only number.';
                                                }
                                            }

                                            if (!values.password) {
                                                errors.password = 'Password is required.';
                                            }
                                            return errors;
                                        }}
                                        onSubmit={(values, { setSubmitting }) => {
                                            this.handleSubmit(values);
                                            setTimeout(() => {
                                                setSubmitting(false);
                                            }, 400);
                                        }}
                                    >
                                        {({
                                            values,
                                            errors,
                                            touched,
                                            handleChange,
                                            handleBlur,
                                            handleSubmit,
                                            isSubmitting
                                        }) => (
                                            <form className="mt-5" onSubmit={handleSubmit}>
                                                <div className="form-group text-left">
                                                    <label>Full Name<sup className="text-danger">*</sup></label>
                                                    <input type="text" name="fullName" value={values.fullName} onChange={handleChange} onBlur={handleBlur} className="form-control" placeholder="Please enter full name" />
                                                    <small className="text-danger">{errors.fullName && touched.fullName && errors.fullName}</small>
                                                </div>
                                                <div className="form-group text-left">
                                                    <label>Email<sup className="text-danger">*</sup></label>
                                                    <input type="email" name="email" value={values.email} onChange={handleChange} onBlur={handleBlur} className="form-control" placeholder="Please enter email" />
                                                    <small className="text-danger">{errors.email && touched.email && errors.email}</small>
                                                </div>
                                                <div className="form-group text-left">
                                                    <label>Phone No.<sup className="text-danger">*</sup></label>
                                                    <input type="text" name="phoneNumber" value={values.phoneNumber} onChange={handleChange} onBlur={handleBlur} className="form-control" placeholder="Please enter phone number" maxLength="10" />
                                                    <small className="text-danger">{errors.phoneNumber && touched.phoneNumber && errors.phoneNumber}</small>
                                                </div>
                                                <div className="form-group text-left">
                                                    <label>Password<sup className="text-danger">*</sup></label>
                                                    <input type="password" name="password" value={values.password} onChange={handleChange} onBlur={handleBlur} className="form-control" placeholder="Please enter password" />
                                                    <small className="text-danger">{errors.password && touched.password && errors.password}</small>
                                                </div>

                                                <div className="from_btm_btns_grp">
                                                    <button type="submit" className="btn btn-primary btn_ani mx-auto mb-3 w-100" id="btnCpLogin" disabled={isSubmitting}>Submit</button>
                                                </div>
                                                <div className="forget_links text-left">
                                                    <Link to="/forgotPwd" className="text-left">Forgot Password?</Link>
                                                    <Link to="/" className="text-left float-right">Login?</Link>
                                                </div>
                                            </form>
                                        )}
                                    </Formik>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </React.Fragment>
        );
    }
}

export default Signup;